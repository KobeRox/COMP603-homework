/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Xu
 */
public class Board {

    int [][] board ;
    int [][] solution;
    boolean gameCompleted;
    private ArrayList<Integer> startingCells;

    //set the board 
    public Board() {
        this.board = new int[9][9];
        gameCompleted = false;
        startingCells = new ArrayList<>();
    }
    
    
    public Board(int[][] board, int[][]solution, ArrayList<Integer> startingCells){
        this.board = board;
        this.gameCompleted = false;
        this.solution = solution;
        this.startingCells = startingCells;
        
    }
    
    //check if game is completed 
    public boolean gameIsCompleted(){
        return gameCompleted;
    }
    //generate a new game 
    public void newGame(){
        startingCells = new ArrayList<>();
        solution = generateSolution(new int[9][9], 0);
        board=generateGame(copy(solution));
        getStartingCells();
    }
    
    //get the starting cell numbers
    private void getStartingCells(){
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if(board[i][j]!=0){
                    startingCells.add(i*9+j);
                }
                
            }
            
        }
    }
    
    //print out the starting cells
     public void printStartingCells()
    {
        for (Integer startingCell : startingCells) {
            System.out.println(startingCell+" ");
        }
    }
    //to generate the solusion 
    private int[][] generateSolution(int[][]game, int index){
        if(index >80){
            return game;
        }
        
        int x = index%9;
        int y = index/9;
        
        List<Integer>numbers = new ArrayList<Integer>();
        for (int i = 1; i <= 9; i++) {
            numbers.add(i);
        }
        Collections.shuffle(numbers);
        //C:\Users\Xu\Documents\NetBeansProjects\W5\src\w5\Board.java
        while(numbers.size()>0){
            int number = getNextPossibleNumber(game,x, y, numbers);
            if(number==-1){
                return null;
            }
            game[y][x] = number;
            int[][]tmpGame = generateSolution(game, index+1);
            if(tmpGame != null){
                return tmpGame;
            }
            game[y][x]=0;
        }
        return null;
    }
    //get both x and y axis number 
    private int getNextPossibleNumber(int[][]game, int x, int y,List<Integer>numbers){
        while(numbers.size()>0){
            int number = numbers.remove(0);
            if(isPossibleX(game, y, number)&& isPossibleY(game, x, number)&&isPossibleBlock(game, x, y, number)){
                return number;
            }
        }
        return -1;
    }
    private boolean isPossibleX(int[][]game, int y, int number){
        for(int x = 0;x < 9;x++){
            if(game[y][x] == number){
                return false;
            }
        }
        return true;
    }
    private boolean isPossibleY(int[][]game, int x, int number){
        for(int y = 0;y<9;y++){
            if(game[y][x]==number){
                return false;
            }
        }
        return true;
    }
    private boolean isPossibleBlock(int[][]game, int x, int y,int number){
        int x1 = x < 3 ? 0 : x < 6 ? 3 : 6 ;
        int y1 = y < 3 ? 0 : y < 6 ? 3 : 6;
        for(int yy = y1; yy < y1+3;yy++){
            for(int xx = x1; xx < x1+3;xx++){
                if(game[yy][xx] == number){
                    return false;
                }
            }
        }
        return true;
    }
    //to generate the game 
    private int[][] generateGame(int[][]game){
        List<Integer>positions = new ArrayList<>();
        for (int i = 0; i < 81; i++) {
            positions.add(i);
        }
        Collections.shuffle(positions);
        return generateGame(game,positions);
    }   
    //to generate initial game board
    private int [][]generateGame(int[][] game, List<Integer>positions){
        while (positions.size()>0){
            int position = positions.remove(0);
            int x = position %9;
            int y = position /9;
            int temp = game[y][x];
            game[y][x]= 0;
            
            if(!isValid(game)){
                game[y][x] = temp;
            }
        }
        return game;
    }
   private boolean isValid(int[][]game){
       return isValid(game,0,new int[]{0});
   }
   //check the validation 
   private boolean isValid(int[][]game, int index, int []numberOfSolutions){
       if(index > 80){
           return ++numberOfSolutions[0] == 1;
       }
       int x = index % 9;
       int y = index / 9;
       
       if(game[y][x] == 0){
           List<Integer>numbers = new ArrayList<Integer>();
           for (int i = 1; i <= 9; i++) {
               numbers.add(i);
           }
           
           while(numbers.size()>0){
               int number = getNextPossibleNumber(game, x, y, numbers);
               if(number == -1){
                   break;
               }
               game[y][x] = number;
               
               if(!isValid(game, index+1, numberOfSolutions)){
                   game[y][x]=0;
                   return false;
               }
               game[y][x] = 0;
           }
       }
       else if(!isValid(game,index+1, numberOfSolutions)){
           return false;
       }
       return true;
   }
   
  private int[][] copy(int[][] game) {
        int[][] copy = new int[9][9];
        for (int y = 0; y < 9; y++) {
            for (int x = 0; x < 9; x++)
                copy[y][x] = game[y][x];
        }
        return copy;
    }
   
   
   public void input(int row, int col, int value){
       board[row][col]  = value;
       
       boolean solved = true;
       for (int i = 0; i < 9; i++) {
           for (int j = 0; j < 9; j++) {
               if(board[i][j]!=solution[i][j]){
                   solved = false;
                   break;
               }
           }
           if(solved){
               gameCompleted = true;
           }
       }
   }
   public boolean isValidInput(int row, int col){
       return !startingCells.contains(row*9+col);
   }
   
   //print out the board
   private void printBoard(int[][]board){
       System.out.println("    1 2 3   4 5 6   7 8 9");
       System.out.println("    ---------------------");
       
       for (int i = 0; i < 9; i++) {
           System.out.print((i+1)+" - ");
           for(int j = 0; j < 9; j++){
               if(startingCells.contains(i*9+j)){
                   System.out.print("\033[0;31m");
                   System.out.print(board[i][j]);
                   System.out.print("\033[0m");
               }
               else{
                   System.out.print(board[i][j]);
               }
               System.out.print(" "+(j==2||j==5?"| ":""));
           }
           System.out.println(""+ (i==2 || i==5?"\n    ---------------------":""));
        }
   }
   
   
   public void printBoard(){
       printBoard(board);
   }
   
   public void printSolution(){
       printBoard(solution);
   }
   
   
   boolean isEmpty(int row, int col){
       return board[row][col]==0;
   }

    @Override
    public String toString() {
        String str = "";
        for (int[] board1 : board) {
            for (int i : board1) {
                str += i+",";
            }
        }
        str+="\n";
        for(int[]board1:solution){
            for(int i : board1){
                str+=i+",";
            }
        }
        str+="\n";
        for(int i:startingCells){
            str+=i+",";
        }
        return str;
    }
   
}
