/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Xu
 */
public class Game {
    
    
    private Board board;
    private String player;
    private Scanner scanner;
    
    //create game 
    public Game(){
        this(new Board(),null);
    }
    
    public Game(Board board,String player){
        this.board = board;
        this.player = player;
        this.scanner = new Scanner(System.in);
    }
    
    //to get the game and using start method 
    public static void main(String[] args) {
        Game game = new Game();
        game.startGame();
        
    }
    
    public void setBoard(Board board){
        this.board = board;
    }
    public void viewBoard(){
        board.printBoard();
    }
    
    
    //check user input, see if it is valid 
    private void saveInputFromUser(){
        int input = 0, value = 0, col = 0, row = 0;
        boolean valid;
        
        do{
            valid = true;
            System.out.println("\nInput number with specify format (row, column, value. E.g. 145): ");
            input = scanner.nextInt();
            row = (input/10)%10-1;
            col = (input/100)%10-1;
            value = input%10;
            
            if(input>999||input<100){
                System.out.println("please follow the format given! ");
                valid = false;
            }
            if(value<1||value>9){
                System.out.println("Value should between 1-9");
                valid = false;
            }
            if(row<0||row>8){
                System.out.println("Invalid row number");
                valid = false;
            }
            if(col<0||col>8){
                System.out.println("Invalid column number");
            }
            if(!board.isValidInput(row, col)){
                System.out.println("Cel is not empty");
                valid = false;
            }
            
        }while(!valid); 
        
        board.input(row, col, value);        
    }
    
    //check what function the user want to use 
    private boolean processStringInputFromUser(){
        boolean exit = false;
        String str = scanner.nextLine();
        if(str.trim().equalsIgnoreCase("answer")){
            board.printSolution();
            exit = true;
            System.exit(0);
        }
        else if(str.trim().equalsIgnoreCase("new game")){
            System.out.println("starting a new game");
            startGame();
        }
        else if(str.trim().equalsIgnoreCase("exit")){
            System.out.println("exit the game");
            exit = true;
        }
        else if(str.trim().equalsIgnoreCase("save")){
            System.out.println("Game saved to the file");
            saveToFile(this);
        }
        else if(str.trim().equalsIgnoreCase("load")){
            System.out.println("load game from last time");
            loadFromFile();
        }
        else{
            System.out.println("invalid input");
        }
        return exit;
    }
    
    //set to start the game 
    public void startGame(){
        board.newGame();
        
        printStartingMessage();
        System.out.println("Use Enter key to start the game");
        scanner.nextLine();
        
        Calendar calendar =  Calendar.getInstance();
        Date startDate  = calendar.getTime();
        
        boolean exit = false;
        do{
            viewBoard();
            try{
                saveInputFromUser();
            }catch(Exception e){
                exit = processStringInputFromUser();
            }
        }while(!board.gameIsCompleted()||!exit);
        calendar = Calendar.getInstance();
        Date finishDate = calendar.getTime();
        long totalDate = finishDate.getTime() - startDate.getTime();
        long seconds = totalDate/1000;
        
        if(board.gameIsCompleted()){
            System.out.println("Good job, to solve this, you spned "+seconds+"'s");
        }
    }
    //print the message welcome usesr 
    public void printStartingMessage(){
        System.out.println("Welcome to sudoku game, hope you enjoy is\n To see the answer, type  \"answer\" \n To play new game, type \"new game\" \n To exit the game, type \"exit\" \n To load game from last time, type \"load\" \n To save to file, type \"save\" \n" );
    }
    //C:\Users\Xu\Documents\NetBeansProjects\W5\src\w5\Game.java
    
    //save to file Sudoku_game_file.txt
    private static void saveToFile(Game game){
        try(
            FileWriter fw = new FileWriter("Sudoku_game_file.txt",false);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw)){
            out.println(game.toString());
        } catch (IOException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public String toString(){
        return board.toString();
    }
    
    //load file from Sudoku_game_file.txt from last time 
    private void loadFromFile(){
        String line = null;
        int[][]board = null, solution = null;
        ArrayList<Integer>startingCells = null;
        
        try (BufferedReader br = new BufferedReader(new FileReader("Sudoku_game_file.txt"))){
            if((line = br.readLine())!=null){
                String[]cells = line.split(",");
                board = new int[9][9];
                for(int i = 0; i < 81; i++){
                    board[i/9][i%9] = Integer.parseInt(cells[i]);
                }
            }
            if((line = br.readLine())!=null){
                String[]cells = line.split(",");
                solution = new int[9][9];
                for(int i = 0; i < 81; i ++){
                    solution[i/9][i%9] = Integer.parseInt(cells[i]);
                }
            }
            if((line = br.readLine())!=null){
                String[] cells = line.split(",");
                startingCells = new ArrayList<>();
                for(int i = 0; i < cells.length; i++){
                    startingCells.add(Integer.parseInt(cells[i]));
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
        setBoard(new Board(board, solution, startingCells));
    }
}
